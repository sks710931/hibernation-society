import React from 'react';
import "./member.scss"
export const MemberBanner = () => {
    return (
        <div className="member-banner-container">
            <h1>Members</h1>
        </div>
    );
}

