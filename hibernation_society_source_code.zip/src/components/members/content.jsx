import React from 'react';
import { Col, Container, Row } from 'react-bootstrap';
import "./member.scss"
export const MembersContent = () => {
    return (
        <div className="members-content">
            <Container>
                <Row>
                    <Col>
                        <p>Coming Soon</p>
                    </Col>
                </Row>
            </Container>
        </div>
    );
}

