import React from 'react';
import "./presale.scss"
export const PresaleBanner = () => {
    return (
        <div className="presale-banner-container">
            <h1>Presale</h1>
        </div>
    );
}

