import React from 'react';
import "./storywall.scss"
export const StoryWallBanner = () => {
    return (
        <div className="storywall-banner-container">
            <h1>#StoryWall</h1>
        </div>
    );
}

