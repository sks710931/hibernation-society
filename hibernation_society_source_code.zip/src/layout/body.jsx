import React from 'react';

export const Body = ({children}) => {
    return (
        <div>
            {children}
        </div>
    );
}
